
print('Hello world')
